# Shoprite Delivery

Grocery delivery app: customers shop by branch, the store packs orders, and drivers deliver them by motorbike, car, van or truck depending on the order weight.

## Run locally
1. Install Node.js
2. `npm install`
3. `npm run dev` and open http://localhost:3000

## Deploy
`npm run build` creates a `dist` folder. Upload it to Netlify, Vercel or Cloudflare Pages (build command `npm run build`, output folder `dist`).

## Where to change things
- `src/main.js`: products and prices (`P`), weights (`W`), vehicles and delivery fees (`VEH`), drivers (`DR`), branches (`BR`)
- `public/images/`: product photos, named by product code
- `src/style.css`: look and feel

## Not built yet
Orders are saved in the browser only. Real payments (MTN MoMo, Airtel Money, card) and a shared backend are still to do.
