import "./style.css";
const P=[{"id": 1, "n": "Whitespoon white sugar, 2 kg", "c": "Staples", "i": "sugar", "p": 58.99}, {"id": 2, "n": "Milano macaroni, 3 kg", "c": "Staples", "i": "milano", "p": 88.99}, {"id": 3, "n": "IBC Nakonde rice, 5 kg", "c": "Staples", "i": "rice", "p": 157.99}, {"id": 4, "n": "Olé vegetable oil, 5 L", "c": "Staples", "i": "ole", "p": 204.99}, {"id": 5, "n": "Bela pasta, 400 g", "c": "Staples", "i": "bela", "p": 21.99}, {"id": 6, "n": "Golden Goodness soya pieces, 400 g", "c": "Staples", "i": "soya", "p": 24.99}, {"id": 7, "n": "Jungle Oats, 1 kg", "c": "Staples", "i": "oats", "p": 64.99}, {"id": 8, "n": "Buttercup Margarine, 500 g", "c": "Dairy & eggs", "i": "buttercup", "p": 39.99}, {"id": 9, "n": "Clover UHT milk, 1 L", "c": "Dairy & eggs", "i": "clover", "p": 32.99}, {"id": 10, "n": "Creambell full cream milk, 475 ml", "c": "Dairy & eggs", "i": "creambell", "p": 11.99}, {"id": 11, "n": "Ultra fat spread, 1 kg", "c": "Dairy & eggs", "i": "ultra", "p": 49.99}, {"id": 12, "n": "Golden Lay mixed eggs, tray of 30", "c": "Dairy & eggs", "i": "eggs", "p": 93.99}, {"id": 13, "n": "Creambell thick yoghurt, 500 g", "c": "Dairy & eggs", "i": "yoghurt", "p": 29.99}, {"id": 14, "n": "Parmalat Gouda cheese slices, 100 g", "c": "Dairy & eggs", "i": "cheese", "p": 27.99}, {"id": 15, "n": "Zamchick frozen chicken portions, 2 kg", "c": "Meat & chicken", "i": "zamchick", "p": 119.99}, {"id": 16, "n": "Lean beef mince, per kg", "c": "Meat & chicken", "i": "mince", "p": 124.99}, {"id": 17, "n": "Pork chops, per kg", "c": "Meat & chicken", "i": "pork", "p": 129.99}, {"id": 18, "n": "Beef chuck & blade, per kg", "c": "Meat & chicken", "i": "chuck", "p": 142.99}, {"id": 19, "n": "Farmer’s Choice whole chicken, per kg", "c": "Meat & chicken", "i": "wholechicken", "p": 59.99}, {"id": 20, "n": "Farmer’s Choice mixed portions, 5 kg", "c": "Meat & chicken", "i": "iqf", "p": 329.99}, {"id": 21, "n": "Meat House breakfast sausage, 300 g", "c": "Meat & chicken", "i": "sausage", "p": 39.99}, {"id": 22, "n": "Medium carrots, 500 g", "c": "Fresh produce", "i": "carrots", "p": 15.99}, {"id": 23, "n": "Golden Delicious / red apples, 1 kg", "c": "Fresh produce", "i": "apples", "p": 39.99}, {"id": 24, "n": "Class 1 potatoes, 3 kg", "c": "Fresh produce", "i": "potatoes", "p": 59.99}, {"id": 25, "n": "Class 1 onions, 3 kg", "c": "Fresh produce", "i": "onions", "p": 59.99}, {"id": 26, "n": "Bigtree Corn Flakes, 500 g", "c": "Pantry & snacks", "i": "cornflakes", "p": 46.99}, {"id": 27, "n": "Dessert topping doughnut", "c": "Pantry & snacks", "i": "doughnut", "p": 11.99}, {"id": 28, "n": "Zam Spread peanut butter, 1 kg", "c": "Pantry & snacks", "i": "peanut", "p": 57.99}, {"id": 29, "n": "Nola mayonnaise, 750 g", "c": "Pantry & snacks", "i": "mayo", "p": 49.99}, {"id": 30, "n": "Ricoffy instant coffee, 100 g", "c": "Pantry & snacks", "i": "ricoffy", "p": 46.99}, {"id": 31, "n": "Lucky Star pilchards, 155 g", "c": "Pantry & snacks", "i": "pilchards", "p": 22.99}, {"id": 32, "n": "Rhodes baked beans, 410 g", "c": "Pantry & snacks", "i": "beans", "p": 24.99}, {"id": 33, "n": "Bull Brand corned meat, 300 g", "c": "Pantry & snacks", "i": "corned", "p": 43.99}, {"id": 34, "n": "Cheetos maize snack, 96 g", "c": "Pantry & snacks", "i": "cheetos", "p": 18.99}, {"id": 35, "n": "Lay’s potato chips, 105 g", "c": "Pantry & snacks", "i": "lays", "p": 29.99}, {"id": 36, "n": "Cadbury Dairy Milk, 150 g", "c": "Pantry & snacks", "i": "dairymilk", "p": 47.99}, {"id": 37, "n": "Coca-Cola / Sprite / Fanta, 2 L", "c": "Drinks", "i": "softdrinks", "p": 24.99}, {"id": 38, "n": "FruiTop cordial, 1.5 L", "c": "Drinks", "i": "fruitop", "p": 24.99}, {"id": 39, "n": "Energade sports drink, 500 ml", "c": "Drinks", "i": "energade", "p": 13.99}, {"id": 40, "n": "Rhodes grape juice blend, 1 L", "c": "Drinks", "i": "grape", "p": 47.99}, {"id": 41, "n": "Rapid washing powder, 4.5 kg", "c": "Household", "i": "rapid", "p": 215.99}, {"id": 42, "n": "Softex toilet tissue, 24 rolls", "c": "Household", "i": "softex", "p": 169.99}, {"id": 43, "n": "Jik bleach, 750 ml", "c": "Household", "i": "jik", "p": 34.99}, {"id": 44, "n": "Sunlight dishwashing liquid, 750 ml", "c": "Household", "i": "sunlight", "p": 34.99}, {"id": 45, "n": "Doom insecticide, 300 ml", "c": "Household", "i": "doom", "p": 39.99}, {"id": 46, "n": "Boom detergent paste, 400 g", "c": "Household", "i": "boompaste", "p": 24.99}, {"id": 47, "n": "Sta-Soft fabric conditioner, 500 ml", "c": "Household", "i": "stasoft", "p": 44.99}, {"id": 48, "n": "Boom washing powder, 1 kg", "c": "Household", "i": "boompowder", "p": 64.99}, {"id": 49, "n": "Colgate Herbal toothpaste, 140 g", "c": "Personal care", "i": "colgate", "p": 28.99}, {"id": 50, "n": "Dettol bath soap, 125 g", "c": "Personal care", "i": "dettol", "p": 9.99}, {"id": 51, "n": "Rexona roll-on, 50 ml", "c": "Personal care", "i": "rexona", "p": 34.99}, {"id": 52, "n": "Vaseline petroleum jelly, 100 ml", "c": "Personal care", "i": "vaseline", "p": 24.99}, {"id": 53, "n": "Vaseline body lotion, 400 ml", "c": "Personal care", "i": "lotion", "p": 84.99}, {"id": 54, "n": "Comfort Care baby diapers", "c": "Baby", "i": "diapers", "p": 114.99}];
const BASE=import.meta.env.BASE_URL;
const IMG=new Proxy({},{get:(_,k)=>`${BASE}images/${k}.jpg`});
const CATS=["All",...new Set(P.map(p=>p.c))];
const AREAS=["Kabulonga","Woodlands","Rhodes Park","Roma","Northmead","Olympia","Chelston","Chilenje","Kalingalinga"];
const STEPS=["Placed","Packing","Ready","On the way","Delivered"];
const FEE=25,FREE_OVER=500;
const W={buttercup:.5,zamchick:2,softdrinks:2,clover:1,cornflakes:.5,sugar:2,milano:3,rice:5,ole:4.6,creambell:.5,ultra:1,eggs:2,bela:.4,mince:1,pork:1,chuck:1,wholechicken:1.5,iqf:5,sausage:.3,doughnut:.1,carrots:.5,apples:1,potatoes:3,onions:3,peanut:1,fruitop:1.5,yoghurt:.5,cheese:.1,mayo:.75,ricoffy:.1,soya:.4,oats:1,pilchards:.16,beans:.41,corned:.3,cheetos:.1,lays:.1,energade:.5,grape:1,dairymilk:.15,colgate:.15,rapid:4.5,softex:2.5,diapers:1.5,dettol:.13,rexona:.06,vaseline:.1,lotion:.4,jik:.75,sunlight:.75,doom:.3,boompaste:.4,stasoft:.5,boompowder:1};
const VEH=[{max:15,n:"Motorbike",k:"bike",fee:25},{max:100,n:"Car",k:"car",fee:60},{max:500,n:"Van",k:"van",fee:150},{max:1e9,n:"Truck",k:"truck",fee:350}];
const DR=[{id:"d1",name:"Mr Danny",phone:"0776 467 008",k:"bike"},{id:"d2",name:"Mr Wana",phone:"0972 720 092",k:"bike"},{id:"d3",name:"Ms Precious",phone:"0574 789 001",k:"bike"},{id:"d4",name:"Joseph Phiri",phone:"097 000 0004",k:"car"},{id:"d5",name:"Bwalya Tembo",phone:"097 000 0005",k:"van"},{id:"d6",name:"Mulenga Banda",phone:"097 000 0006",k:"van"},{id:"d7",name:"Mwansa Zulu",phone:"097 000 0007",k:"truck"}];
const vehOf=w=>VEH.find(v=>w<=v.max);
const vehName=k=>VEH.find(v=>v.k===k).n;
const drv=id=>DR.find(d=>d.id===id);
let me="d1";
const $=s=>document.querySelector(s);
const esc=s=>String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const K=n=>"K"+n.toFixed(2);
const BR=["Manda Hill","Waterfalls Mall","East Park Mall","Arcades","Cairo Road","Makeni Mall","Cosmopolitan Mall","Pinnacle Mall","Great North Mall"];
let branch=BR[0];
let role="customer",cat="All",q="",cart={},orders=[],err="",pay="momo-mtn",form={name:"",phone:"",area:AREAS[0],addr:"",momo:""};
try{orders=JSON.parse(localStorage.getItem("sr-orders")||"[]")}catch(e){orders=[]}
const save=()=>{try{localStorage.setItem("sr-orders",JSON.stringify(orders))}catch(e){}};
const toast=m=>{const t=$("#toast");t.textContent=m;t.style.display="block";clearTimeout(toast.t);toast.t=setTimeout(()=>t.style.display="none",2400)};
const lines=()=>Object.entries(cart).map(([id,n])=>({p:P.find(x=>x.id==id),n}));
const sub=()=>lines().reduce((s,l)=>s+l.p.p*l.n,0);
const fee=()=>{if(!sub())return 0;const v=vehOf(wt());return v.k==="bike"&&sub()>=FREE_OVER?0:v.fee};
const wt=()=>lines().reduce((s,l)=>s+(W[l.p.i]||1)*l.n,0);
const busy=d=>orders.filter(o=>o.driver===d.id&&o.s<4).length;
const pickDriver=k=>{const pool=DR.filter(d=>d.k===k);return [...(pool.length?pool:DR)].sort((a,b)=>busy(a)-busy(b))[0].id};
const dispatch=o=>o.driver&&drv(o.driver)?`<div class="muted">${esc(o.vehicle)} delivery, ${o.wt.toFixed(1)} kg. Driver: ${esc(drv(o.driver).name)}, ${esc(drv(o.driver).phone)}</div>`:"";
const count=()=>Object.values(cart).reduce((a,b)=>a+b,0);
const HERO=`${BASE}images/hero.jpg`;
const hero=()=>`<section class="hero"><div><span class="pill">Doorstep delivery</span><h1>Groceries for home, without the extra trip.</h1><p class="lead">Shop real Shoprite products, pick your branch and pay with mobile money, cash or card. The branch packs it and a driver brings it to your door.</p><div class="hbtns"><button class="btn lg" data-act="start">Start shopping</button><button class="btn lg ghost" data-act="branch">Choose branch</button></div><p class="muted">Packed at ${esc(branch)} and delivered across Lusaka.</p></div><div class="collage" aria-hidden="true"><img src="${HERO}" alt=""><div class="float"><b>Everything on your list</b><div class="muted">Pantry, fresh food and home care</div></div></div></section>`;
const PAYNAME={"momo-mtn":"MTN MoMo","momo-airtel":"Airtel Money",cod:"Cash on delivery",card:"Card"};

function tracker(o){return `<ol class="steps">${STEPS.map((s,i)=>`<li class="${i<=o.s?"done":""}">${s}</li>`).join("")}</ol>`}
function orderItems(o){return o.items.map(i=>`${i.n}× ${esc(i.name)}`).join(", ")}

function qtyCtl(p){const n=cart[p.id]||0;
return n?`<div class="qty"><button data-act="dec" data-id="${p.id}" aria-label="Remove one ${esc(p.n)}">−</button><b>${n}</b><button data-act="inc" data-id="${p.id}" aria-label="Add one ${esc(p.n)}">+</button></div>`
:`<button class="add" data-act="inc" data-id="${p.id}">Add to cart</button>`}

function shop(){
 const list=P.filter(p=>(cat==="All"||p.c===cat)&&p.n.toLowerCase().includes(q.toLowerCase()));
 const mine=orders.filter(o=>o.s<4),done=orders.filter(o=>o.s===4);
 return `${q?"":hero()}
 ${mine.map(o=>`<section class="panel" aria-label="Order ${o.id}"><div class="row"><b>Order ${o.id}</b><span class="tag">${STEPS[o.s]}</span></div>${tracker(o)}<div class="muted">${orderItems(o)} · ${K(o.total)} · ${PAYNAME[o.pay]}</div>${dispatch(o)}</section>`).join("")}
 <h2 id="products">${q?`Results for “${esc(q)}”`:"Shop the catalogue"}</h2>
 <div class="chips">${CATS.map(c=>`<button class="chip" data-act="cat" data-v="${esc(c)}" aria-pressed="${c===cat}">${esc(c)}</button>`).join("")}</div>
 ${list.length?`<div class="grid">${list.map(p=>`<div class="card"><img class="pic" src="${IMG[p.i]}" alt="${esc(p.n)}"><div>${esc(p.n)}</div><div class="price">${K(p.p)}</div>${qtyCtl(p)}</div>`).join("")}</div>`:`<div class="empty">No products match “${esc(q)}”. Try a shorter word or pick another category.</div>`}
 <p class="muted">Products and prices are taken from the Shoprite Zambia catalogue (offers valid 5 to 18 October 2026). Delivery fees depend on the vehicle: ${VEH.map(v=>`${v.n.toLowerCase()} ${K(v.fee)}`).join(", ")}. Motorbike delivery is free on orders of ${K(FREE_OVER)} or more.</p>
 ${done.length?`<h2>Past orders</h2>${done.map(o=>`<div class="panel row"><span><b>${o.id}</b> · ${orderItems(o)}</span><span>${K(o.total)}</span></div>`).join("")}`:""}`}

function card(o,btn){return `<div class="panel"><div class="row"><b>${o.id}</b><span class="muted">${o.time}</span></div>
 <div>${orderItems(o)}</div><div class="muted"><b>${esc(o.branch||"")}</b><br>${o.vehicle?`${esc(o.vehicle)} load, ${o.wt.toFixed(1)} kg, driver ${esc(drv(o.driver)?.name||"unassigned")}<br>`:""}${esc(o.name)} · ${esc(o.phone)}<br>${esc(o.addr)}, ${esc(o.area)}</div>
 <div class="row" style="margin-top:6px"><b>${K(o.total)}</b><span class="tag">${o.pay==="cod"?"Collect cash":"Paid via "+PAYNAME[o.pay]}</span></div>${btn}</div>`}
function board(title,s,label,cls,mine){const l=orders.filter(o=>o.s===s&&(!mine||o.driver===me));
 return `<section><h2>${title} (${l.length})</h2>${l.length?l.map(o=>card(o,label?`<button class="btn ${cls||""} full" data-act="adv" data-id="${o.id}">${label}</button>`:"")).join(""):`<div class="empty">Nothing here right now.</div>`}</section>`}
function store(){return `<h1>Store orders</h1><p class="muted">Pack new orders and mark them ready for a driver.</p><div class="cols">${board("New",0,"Start packing")}${board("Packing",1,"Mark ready for pickup","alt")}${board("Waiting for driver",2,"")}</div>`}
function driver(){return `<h1>Deliveries</h1><label for="me">Signed in as</label><select class="in" id="me" style="max-width:360px">${DR.map(d=>`<option value="${d.id}" ${d.id===me?"selected":""}>${d.name} (${vehName(d.k)})</option>`).join("")}</select><p class="muted">Pick up ready orders and mark them delivered.</p><div class="cols">${board("Ready for pickup",2,"Pick up order","",true)}${board("On the way",3,"Mark delivered","alt",true)}${board("Delivered",4,"","",true)}</div>`}

function cartHTML(){
 const L=lines();
 if(!L.length)return `<div class="row"><h2 style="margin:0">Your cart</h2><button class="btn" data-act="close">Close</button></div><div class="empty" style="margin-top:16px">Your cart is empty. Add items from the shop to get started.</div>`;
 return `<div class="row"><h2 style="margin:0">Your cart</h2><button class="btn" data-act="close">Close</button></div>
 ${L.map(l=>`<div class="panel row"><span><img class="thumb" src="${IMG[l.p.i]}" alt="">${esc(l.p.n)}<br><b>${K(l.p.p*l.n)}</b></span><span style="width:120px">${qtyCtl(l.p)}</span></div>`).join("")}
 <div class="panel"><div class="row"><span>Subtotal</span><span>${K(sub())}</span></div><div class="row"><span>Delivery</span><span>${fee()?K(fee()):"Free"}</span></div><div class="row"><span>Order weight</span><span>${wt().toFixed(1)} kg</span></div><div class="row"><span>Delivered by</span><span>${vehOf(wt()).n}</span></div><div class="row"><b>Total</b><b>${K(sub()+fee())}</b></div></div>
 <h2>Delivery details</h2>
 <label for="f-name">Full name</label><input class="in" id="f-name" data-f="name" value="${esc(form.name)}" autocomplete="name">
 <label for="f-phone">Phone number</label><input class="in" id="f-phone" data-f="phone" type="tel" placeholder="097 123 4567" value="${esc(form.phone)}" autocomplete="tel">
 <label for="f-area">Area</label><select class="in" id="f-area" data-f="area">${AREAS.map(a=>`<option ${a===form.area?"selected":""}>${a}</option>`).join("")}</select>
 <label for="f-addr">Street address or landmark</label><input class="in" id="f-addr" data-f="addr" value="${esc(form.addr)}" autocomplete="street-address">
 <h2>Payment</h2>
 <div class="pay">${Object.entries(PAYNAME).map(([k,v])=>`<label><input type="radio" name="pay" value="${k}" ${k===pay?"checked":""}>${v}</label>`).join("")}</div>
 ${pay.startsWith("momo")?`<label for="f-momo">${PAYNAME[pay]} number</label><input class="in" id="f-momo" data-f="momo" type="tel" value="${esc(form.momo)}"><p class="muted">You will get an approval prompt on this number.</p>`:""}
 ${pay==="card"?`<p class="muted">Card payment needs a payment gateway. In this version the order is recorded as paid.</p>`:""}
 <div class="err" role="alert">${esc(err)}</div>
 <button class="btn full" data-act="place">Place order · ${K(sub()+fee())}</button>`}

function render(){
 document.querySelectorAll("#tabs button").forEach(b=>b.setAttribute("aria-pressed",b.dataset.role===role));
 $("#cartbtn").style.display=role==="customer"?"":"none";$("#q").style.display=role==="customer"?"":"none";$(".branch").style.display=role==="customer"?"":"none";$("#cartbtn").innerHTML=`Cart <span class="badge">${count()}</span>`;
 $("#app").innerHTML=role==="customer"?shop():role==="store"?store():driver();
 
 if($("#sheet").classList.contains("open")){const y=$("#drawer").scrollTop;$("#drawer").innerHTML=cartHTML();$("#drawer").scrollTop=y}
}
function place(){
 if(!form.name.trim())return fail("Enter your full name.");
 if(!/^[+\d][\d\s]{8,14}$/.test(form.phone.trim()))return fail("Enter a valid phone number, for example 097 123 4567.");
 if(!form.addr.trim())return fail("Enter your street address or a nearby landmark.");
 if(pay.startsWith("momo")&&!/^[+\d][\d\s]{8,14}$/.test(form.momo.trim()))return fail("Enter the mobile money number to charge.");
 const id="SR-"+(1001+orders.length),w=wt(),v=vehOf(w);
 orders.unshift({id,s:0,items:lines().map(l=>({n:l.n,name:l.p.n})),total:sub()+fee(),pay,branch,wt:w,vehicle:v.n,driver:pickDriver(v.k),name:form.name.trim(),phone:form.phone.trim(),area:form.area,addr:form.addr.trim(),time:new Date().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})});
 save();cart={};err="";$("#sheet").classList.remove("open");toast(`Order ${id} placed`);render();
}
function fail(m){err=m;render()}

document.addEventListener("click",e=>{
 const t=e.target.closest("[data-act],[data-role]");if(!t)return;
 if(t.dataset.role){role=t.dataset.role;render();return}
 const a=t.dataset.act,id=t.dataset.id;
 if(a==="start"){$("#products").scrollIntoView({behavior:"smooth"});return}
 if(a==="branch"){$("#branch").focus();return}
 if(a==="inc"){cart[id]=(cart[id]||0)+1}
 else if(a==="dec"){cart[id]=(cart[id]||1)-1;if(cart[id]<1)delete cart[id]}
 else if(a==="cat"){cat=t.dataset.v}
 else if(a==="close"){$("#sheet").classList.remove("open");err=""}
 else if(a==="place"){place();return}
 else if(a==="adv"){const o=orders.find(x=>x.id===id);if(o){o.s++;save();toast(`${o.id}: ${STEPS[o.s]}`)}}
 render();
});
$("#cartbtn").addEventListener("click",()=>{$("#sheet").classList.add("open");render()});
$("#sheet").addEventListener("click",e=>{if(e.target.id==="sheet"){$("#sheet").classList.remove("open")}});
document.addEventListener("keydown",e=>{if(e.key==="Escape")$("#sheet").classList.remove("open")});
document.addEventListener("input",e=>{
 if(e.target.id==="q"){q=e.target.value;render()}
 else if(e.target.dataset.f){form[e.target.dataset.f]=e.target.value}
});
document.addEventListener("change",e=>{
 if(e.target.name==="pay"){pay=e.target.value;err="";render()}
 else if(e.target.dataset.f==="area"){form.area=e.target.value}
 else if(e.target.id==="me"){me=e.target.value;render()}
});
$("#branch").innerHTML=BR.map(b=>`<option>${b}</option>`).join("");
$("#branch").addEventListener("change",e=>{branch=e.target.value;render()});
render();
